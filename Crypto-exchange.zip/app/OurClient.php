<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OurClient extends Model
{
    protected $guarded = [];
    protected $table = "our_clients";
}
