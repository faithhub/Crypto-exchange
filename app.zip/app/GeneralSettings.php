<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GeneralSettings extends Model
{
    protected $guarded = [];

    protected $table = "basic_settings";
}
